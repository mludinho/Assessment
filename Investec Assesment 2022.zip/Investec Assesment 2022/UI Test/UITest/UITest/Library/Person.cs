﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Linq;

namespace UITest.Library
{
    public class Person
    {
        private const string  sURL = "https://swapi.dev/api/people/";

        public void IntializePersonList()
        {
            // Initialize and get List Of Person objects this is to populate the list of people.
            try
            {
                using (HttpClient client = new HttpClient())
                {
                    var response = client.GetAsync(sURL);
                    if (response != null)
                    {
                        var jsonString = response.Result.Content.ReadAsStringAsync().Result;
                        var peopleList = JsonConvert.DeserializeObject<Root>(jsonString);
                        ListPeople = peopleList.results;
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Result> ListPeople { get; set; }

        public Result GetPerson(string name)
        {
            return ListPeople.FirstOrDefault(x => x.name == name);
        }
    }
}
