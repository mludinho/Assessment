﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.Text;
using UITest.Pages;

namespace UITest.Tests
{
    class UITest
    {
        //Instantiate Chrome driver
        IWebDriver webDriver = new ChromeDriver();

        //Hooks
        [SetUp]
        public void Setup()
        {
            // Navigate to the Investec Site
            webDriver.Navigate().GoToUrl("https://www.investec.com/");
            // Navigate to this site 
            webDriver.Navigate().GoToUrl("https://www.investec.com/en_za/focus/money/understanding-interest-rates.html");
        }

        [Test]
        public void SignUp()
        {
            HomePage homepage = new HomePage(webDriver);
            homepage.SignUpClick();

            // Pass in User data for multple logins/Easy Maintanance we can move this to a file and maintain the file to read from a file
            SignUpPage sigupPage = new SignUpPage(webDriver);
            sigupPage.SignUp("Mlungisi", "Magwenyane", "test@investec.co.za",true,false,true);
        }


        // This is to close the open browsers when SignUp is done
        //[TearDown]
        //public void TearDown() => webDriver.Quit();

    }
}
