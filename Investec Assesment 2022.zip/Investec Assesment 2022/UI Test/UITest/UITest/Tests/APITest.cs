﻿using Newtonsoft.Json;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Text;
using UITest.Library;

namespace UITest.Tests
{
    public class APITest
    {
        [Test]
        public void TestColor()
        {
            //Get Person Object by name then run test and Assertion
            Person pObject = new Person();
            pObject.IntializePersonList();
            var result = pObject.GetPerson("R2-D2");
            Assert.AreEqual("white, blue", result.skin_color);
        }
    }
}
