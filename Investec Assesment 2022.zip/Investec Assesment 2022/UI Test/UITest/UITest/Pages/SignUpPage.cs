﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;
using System.Text.RegularExpressions;
using System.Linq;

namespace UITest.Pages
{
    public class SignUpPage
    {
        public SignUpPage(IWebDriver webDeiver)
        {
            Driver = webDeiver;
        }
        public IWebDriver Driver { get; }

        IWebElement txtName => Driver.FindElement(By.Name("name"));
        IWebElement txtSurname => Driver.FindElement(By.Name("surname"));
        IWebElement txtEmail => Driver.FindElement(By.Name("email"));
        ReadOnlyCollection<IWebElement> chkInsightsList => Driver.FindElements(By.XPath("//div[@class='checkbox-input__button-copy ng-binding']"));
        IWebElement btnSignUp => Driver.FindElement(By.XPath("//button[contains(text(), 'Submit')]"));

        public void SignUp (string name,string surname, string email,bool isMyself,bool isIntermediaries ,bool isMyBusiness)
        {
            txtName.SendKeys(name);
            txtSurname.SendKeys(surname);
            txtEmail.SendKeys(email);

            // Select Insights being requested it can be any or all
            
            if (isMyself)
                chkInsightsList.First().Click();
            if (isIntermediaries)
                chkInsightsList.Skip(1).First().Click();
            if (isMyBusiness)
                chkInsightsList.Skip(2).First().Click();
            //Sumit Captured information
            btnSignUp.Submit();
        }
    }
}
