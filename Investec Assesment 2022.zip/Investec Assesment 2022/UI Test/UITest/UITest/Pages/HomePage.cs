﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Text;

namespace UITest.Pages
{
    public class HomePage
    {

        public HomePage(IWebDriver webDeiver)
        {
            Driver = webDeiver;
        }
        private IWebDriver Driver { get; }

        public IWebElement btnSignUp => Driver.FindElement(By.XPath("//button[contains(text(), 'Sign up')]"));

        public void SignUpClick() => btnSignUp.Click();

    }
}
